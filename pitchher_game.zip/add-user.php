<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin</title>
</head>
<body>
<div id="contact">
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">

    <h2>Enter a user name to start:</h2>
    <input type="text" name="txtUserName">

      <button id="btnGo" type="submit" name="submit" class="btn_submit">Go</button>

    </form>
    <?php

    //Create Database Connection
    $databaseHost = "localhost";
    $databaseName = "id20151415_pitchher";
    $databaseUsername = "id20151415_user2023";
    $databasePassword = "Shehacks@2023";

    $mysqli = new mysqli($databaseHost, $databaseUsername, $databasePassword, $databaseName);
    if ($mysqli->connect_error) {
        die("Connect Failed: " . $conn->connect_error);
      }
      else{
          echo 'connected';
      }

 
        
    if (isset($_POST['submit'])) {
      $userName = $_POST['txtUserName'];
     
    if(!empty($userName)){
        
        $userCounts = mysqli_query($mysqli, "select count(userId) user");
        echo '$userCounts';
        if($userCounts <=3){

      // Insert Data Statement
      $result = mysqli_query($mysqli, "INSERT INTO user(userName,roleId)
                          VALUES('$userName','0')");
      if ($result) {
        echo "<h2>Registration Successfully</h2>";
      } else {
        echo "<h2>failed:</h2>";
      }
    }
    
    }
        else{
            echo 'We have a full game!!';
        }
    }
    else{
        echo 'Please Enter Your Name!';
    }
    ?>
      
      
      
  
     
</body>
</html>