var randNum = [];
const LOOP = 5;

btnGenCode.addEventListener("click", genCode);

function genCode() {
  randNum = [];
  for (let i = 0; i < LOOP; i++) {
    randNum.push(Math.floor(Math.random() * 10));
  }

  document.getElementById("genCodeOutput").innerHTML = randNum.join(" ");
}
