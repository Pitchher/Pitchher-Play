// Role

var roleArray = []; // 0:customer 1:salesperson
var setCust = 0;

function Users(userName, roleType) {
  this.userName = userName;
  this.roleType = roleType;
}
var user1 = roleArray.push(new Users("User1"));
var user2 = roleArray.push(new Users("User2"));
var user3 = roleArray.push(new Users("User3"));
var user4 = roleArray.push(new Users("User4"));
var user5 = roleArray.push(new Users("User5"));

setCust = Math.floor(Math.random() * 5);
for (let i = 0; i < 5; i++) {
  if (setCust == i) {
    roleArray[i].roleType = 1;
  } else {
    roleArray[i].roleType = 0;
  }
}

